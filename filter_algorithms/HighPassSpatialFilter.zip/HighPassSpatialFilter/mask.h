struct Mask{
int Rows;
int Cols;
unsigned char *Data;
};

